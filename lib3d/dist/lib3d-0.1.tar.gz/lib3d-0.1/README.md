# 3Dlib
This repo is a Pointcloud , Mesh manipulations package for SceneRecon , ObjectDetection and PoseEstimation in ROS , python and C++

